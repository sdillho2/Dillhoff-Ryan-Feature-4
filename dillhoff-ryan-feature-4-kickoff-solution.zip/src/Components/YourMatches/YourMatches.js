export default function YourMatches() {
  return (
    <section>
      <h1> Welcome to YourMatches Components </h1>
      <p> This is the YourMatches component </p>
    </section>
  );
}
