module.exports = {
  APPLICATION_ID: "LG9Z5QPaxemHcp1R5ENzej17Dt4FVFmnZaGhdJy5",
  JAVASCRIPT_KEY: "LF6yM7u7jES772l9wLgpRacpjng5H1WuvQIpcDEs",
  SERVER_URL: "https://parseapi.back4app.com/"
};